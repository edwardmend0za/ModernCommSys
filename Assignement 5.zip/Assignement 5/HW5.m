%First PAM modulation/demodulation
% Set up parameters
k = 3; % Bit per symbol
M = 2^k; % Number of symbols

% 1. Create 10,000 input data with a random distribution
N = [10000 1];
i_data = randi([0,M-1], N);

% 2. Modulate & demodulate using PAM with M=2 and show constellation
tx_sig_pam2 = pammod(i_data, M);
o_data_pam2 = pamdemod(tx_sig_pam2, M);

% Compare output data with input data and report number of errors
fprintf('Number of errors (PAM, M=2): %i\n', sum(i_data ~= o_data_pam2));

% Convert Eb/N0 from dB to linear scale
ebno_db = sum(i_data ~= o_data_pam2); 
ebno_linear = 10^(ebno_db/10); % Convert dB to linear scale

errprob = qfunc(sqrt(2 * ebno_linear));

fprintf('The Error probability is: %f\n', errprob);