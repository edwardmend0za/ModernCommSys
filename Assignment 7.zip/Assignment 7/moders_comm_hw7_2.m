%{
% Parameters
N = 100000;             % Number of data bits
SNR_dB = 6;             % Signal-to-Noise Ratio (dB)
k = 4;                  % Number of data bits per code word (for BCH)
n = 7;                  % Total number of bits per code word (including parity bits) (for BCH)

% Generate random data bits
data_bits = randi([0 1], 1, N);

%% Hamming Block Code (BCH)
% Create BCH codes
h = hammgen(3);         % Parity check matrix
g = gen2par(h);         % Generator matrix
synd_table = syndtable(h); % Table of syndromes

% Reshape input bits into blocks of k bits
input_blocks = reshape(data_bits, [], k);

% Encode using BCH
codewords_bch = mod(input_blocks * g, 2);

% BPSK modulation
modulated_symbols_bch = 2 * codewords_bch - 1;

% AWGN Channel
SNR = 10^(SNR_dB/10);
noise_var = 1 / SNR;
noise = sqrt(noise_var) * randn(size(modulated_symbols_bch));
received_symbols_bch = modulated_symbols_bch + noise;

% BPSK demodulation
received_codewords_bch = (received_symbols_bch > 0);

% Correct demodulated BCH codewords to match the original data bits
demodulated_bch_bits = reshape(received_codewords_bch(:, 1:k)', 1, []);

% Calculate number of errors and BER for BCH code
num_errors_bch = sum(demodulated_bch_bits ~= data_bits);
ber_bch = num_errors_bch / N;

%% Convolutional Code
% Create convolutional code trellis
constraint_length = 3;
polynomials = [6 7]; % Generator polynomials
trellis = poly2trellis(constraint_length, polynomials);

% Encode using convolutional code
codewords_conv = convenc(data_bits, trellis);

% BPSK modulation
modulated_symbols_conv = 2 * codewords_conv - 1;

% AWGN Channel
noise = sqrt(noise_var) * randn(size(modulated_symbols_conv));
received_symbols_conv = modulated_symbols_conv + noise;

% BPSK demodulation
received_codewords_conv = (received_symbols_conv > 0);

% Viterbi decoding
tbdepth = 34; % Traceback depth
decoded_bits = vitdec(received_codewords_conv, trellis, tbdepth, 'trunc', 'hard');

% Calculate number of errors and BER for Convolutional code
num_errors_conv = sum(decoded_bits ~= data_bits);
ber_conv = num_errors_conv / N;

% Display results
disp(['Number of errors for BCH Code: ', num2str(num_errors_bch)]);
disp(['Bit Error Rate (BER) for BCH Code: ', num2str(ber_bch)]);
disp(['Number of errors for Convolutional Code: ', num2str(num_errors_conv)]);
disp(['Bit Error Rate (BER) for Convolutional Code: ', num2str(ber_conv)]);
%}

% Parameters
N = 100000;             % Number of data bits
SNR_dB = 6;             % Signal-to-Noise Ratio (dB)
k = 4;                  % Number of data bits per code word (for BCH)
n = 7;                  % Total number of bits per code word (including parity bits) (for BCH)

% Generate random data bits
data_bits = randi([0 1], 1, N);

%% Uncoded Version
% BPSK modulation
modulated_symbols_uncoded = 2 * data_bits - 1;

% AWGN Channel
SNR = 10^(SNR_dB/10);
noise_var = 1 / SNR;
noise = sqrt(noise_var) * randn(size(modulated_symbols_uncoded));
received_symbols_uncoded = modulated_symbols_uncoded + noise;

% BPSK demodulation
received_bits_uncoded = (received_symbols_uncoded > 0);

% Calculate number of errors and BER for uncoded version
num_errors_uncoded = sum(received_bits_uncoded ~= data_bits);
ber_uncoded = num_errors_uncoded / N;

%% Hamming Block Code (BCH)
% Create BCH codes
h = hammgen(3);         % Parity check matrix
g = gen2par(h);         % Generator matrix
synd_table = syndtable(h); % Table of syndromes

% Reshape input bits into blocks of k bits
input_blocks = reshape(data_bits, [], k);

% Encode using BCH
codewords_bch = mod(input_blocks * g, 2);

% BPSK modulation
modulated_symbols_bch = 2 * codewords_bch - 1;

% AWGN Channel
noise = sqrt(noise_var) * randn(size(modulated_symbols_bch));
received_symbols_bch = modulated_symbols_bch + noise;

% BPSK demodulation
received_codewords_bch = (received_symbols_bch > 0);

% Correct demodulated BCH codewords to match the original data bits
demodulated_bch_bits = reshape(received_codewords_bch(:, 1:k)', 1, []);

% Calculate number of errors and BER for BCH code
num_errors_bch = sum(demodulated_bch_bits ~= data_bits);
ber_bch = num_errors_bch / N;

%% Convolutional Code
% Create convolutional code trellis
constraint_length = 3;
polynomials = [6 7]; % Generator polynomials
trellis = poly2trellis(constraint_length, polynomials);

% Encode using convolutional code
codewords_conv = convenc(data_bits, trellis);

% BPSK modulation
modulated_symbols_conv = 2 * codewords_conv - 1;

% AWGN Channel
noise = sqrt(noise_var) * randn(size(modulated_symbols_conv));
received_symbols_conv = modulated_symbols_conv + noise;

% BPSK demodulation
received_codewords_conv = (received_symbols_conv > 0);

% Viterbi decoding
tbdepth = 34; % Traceback depth
decoded_bits = vitdec(received_codewords_conv, trellis, tbdepth, 'trunc', 'hard');

% Calculate number of errors and BER for Convolutional code
num_errors_conv = sum(decoded_bits ~= data_bits);
ber_conv = num_errors_conv / N;

% Display results
disp('--- Results ---');
disp('Uncoded:');
disp(['Number of errors: ', num2str(num_errors_uncoded)]);
disp(['Bit Error Rate (BER): ', num2str(ber_uncoded)]);
disp('Hamming Block Code (BCH):');
disp(['Number of errors: ', num2str(num_errors_bch)]);
disp(['Bit Error Rate (BER): ', num2str(ber_bch)]);
disp('Convolutional Code:');
disp(['Number of errors: ', num2str(num_errors_conv)]);
disp(['Bit Error Rate (BER): ', num2str(ber_conv)]);
