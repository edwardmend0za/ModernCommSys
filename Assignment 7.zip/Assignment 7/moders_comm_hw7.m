% Parameters
N = 100000;             % Number of data bits
SNR_dB = 6;             % Signal-to-Noise Ratio (dB)
k = 4;                  % Number of data bits per code word
n = 7;                  % Total number of bits per code word (including parity bits)

% Generate random data bits
data_bits = randi([0 1], 1, N);

% Create BCH codes
h = hammgen(3);         % Parity check matrix
g = gen2par(h);         % Generator matrix
synd_table = syndtable(h); % Table of syndromes

% Reshape input bits into blocks of k bits
%input_blocks = reshape(data_bits, [], k);
input_blocks = reshape(data_bits,(N/k), k);

% Encode using BCH
codewords = mod(input_blocks * g, 2);

% BPSK modulation
modulated_symbols = 2 * codewords - 1;

% AWGN Channel
SNR = 10^(SNR_dB/10);
noise_var = 1 / SNR;
noise = sqrt(noise_var) * randn(size(modulated_symbols));
received_symbols = modulated_symbols + noise;

% BPSK demodulation
received_codewords = (received_symbols > 0);

% Count the number of errors
num_errors = sum(received_codewords(:) ~= codewords(:));

% Calculate BER
ber_estimated = num_errors / (N * n); % N is the number of blocks, n is the number of bits per block

disp(['Estimated Bit Error Rate (BER): ', num2str(ber_estimated)]);

% Calculate syndromes
rx_syndromes = mod(received_codewords * h', 2);

% Convert syndromes to integer values
syndrome_indices = bi2de(rx_syndromes,"left-msb");

% Lookup error vectors
error_vectors = synd_table(syndrome_indices + 1, :);

% Correct received codewords
%corrected_codewords = mod(received_codewords + error_vectors, 2);
corrected_codewords = bitxor(received_codewords,error_vectors);

% Extract corrected messages
corrected_messages = corrected_codewords(:, 1:k);

% Flatten messages to vector
corrected_data_bits = corrected_messages(:)';

% Display bit error rate
ber = sum(corrected_data_bits ~= data_bits) / N;
disp(['Bit Error Rate (BER): ', num2str(ber)]);
