% Set up parameters
k = 3; % Bit per symbol
M = 2^k; % Number of symbols

% 1. Create 10,000 input data with a random distribution
N = [10000 1];
i_data = randi([0,M-1], N);

% 2. Modulate & demodulate using PAM with M=2 and show constellation
tx_sig_pam2 = pammod(i_data, M);
o_data_pam2 = pamdemod(tx_sig_pam2, M);

% Compare output data with input data and report number of errors
fprintf('Number of errors (PAM, M=2): %i\n', sum(i_data ~= o_data_pam2));

% Display the constellation using scatterplot

scatterplot(tx_sig_pam2);
title('Constellation (PAM, M=2)');
saveas(gcf, 'constellation_pam2.fig');
saveas(gcf, 'constellation_pam2.png');

% 3. Repeat (2) with k=3 & M=8
M = 8;
i_data = randi([0,M-1], N);
tx_sig_pam8 = pammod(i_data, M);
o_data_pam8 = pamdemod(tx_sig_pam8, M);
fprintf('Number of errors (PAM, M=8): %i\n', sum(i_data ~= o_data_pam8));


scatterplot(tx_sig_pam8);
title('Constellation (PAM, M=8)');
saveas(gcf, 'constellation_pam8.fig');
saveas(gcf, 'constellation_pam8.png');

% 4. Repeat above with QAM, but now use N=[10000*k 1]
k = 1;
M = 2^k;
N = [10000*k 1];
i_data = randi([0 1], N);
tx_sig_qam2 = qammod(i_data, M, 'InputType', 'bit', 'UnitAveragePower', true);
o_data_qam2 = qamdemod(tx_sig_qam2, M, 'OutputType', 'bit');
fprintf('Number of errors (QAM, M=2): %i\n', sum(i_data ~= o_data_qam2));


scatterplot(tx_sig_qam2);
title('Constellation (QAM, M=2)');
saveas(gcf, 'constellation_qam2.fig');
saveas(gcf, 'constellation_qam2.png');

% 5. Repeat above with 64-QAM
M = 64;
i_data = randi([0 M-1], N);
tx_sig_qam64 = qammod(i_data, M, 'UnitAveragePower', true);
o_data_qam64 = qamdemod(tx_sig_qam64, M);
fprintf('Number of errors (QAM, M=64): %i\n', sum(i_data ~= o_data_qam64));


scatterplot(tx_sig_qam64);
title('Constellation (QAM, M=64)');
saveas(gcf, 'constellation_qam64.fig');
saveas(gcf, 'constellation_qam64.png');

% 6. Repeat above with PSK with M=8 (8-PSK)
M = 8;
i_data = randi([0 M-1], N);
tx_sig_psk8 = pskmod(i_data, M);
o_data_psk8 = pskdemod(tx_sig_psk8, M);
fprintf('Number of errors (PSK, M=8): %i\n', sum(i_data ~= o_data_psk8));


scatterplot(tx_sig_psk8);
title('Constellation (PSK, M=8)');
saveas(gcf, 'constellation_psk8.fig');
saveas(gcf, 'constellation_psk8.png');

% 7. Change the symbol order to Gray coding for 64-QAM modulator
tx_sig_qam64_gray = qammod(i_data, M, "gray");

% Demodulator using binary coding
o_data_qam64_gray_binary = qamdemod(tx_sig_qam64_gray, M,'OutputType','integer');

% Report the number of errors
fprintf('Number of errors (QAM, M=64, Gray to Binary): %i\n', sum(i_data ~= o_data_qam64_gray_binary));

% Demodulator using Gray coding
o_data_qam64_gray = qamdemod(tx_sig_qam64_gray, M ,'gray');

% Report the number of errors
fprintf('Number of errors (QAM, M=64, Gray to Gray): %i\n', sum(i_data ~= o_data_qam64_gray));

% 8. For 64-QAM and 8-PSK, add awgn with SNR of 20 dB
rx_sig_qam64_20dB = awgn(tx_sig_qam64, 20);
rx_sig_psk8_20dB = awgn(tx_sig_psk8, 20);

% Show received constellation using scatterplot and report the number of errors

scatterplot(rx_sig_qam64_20dB);
title('Received Constellation (QAM, M=64, SNR=20 dB)');
saveas(gcf, 'received_constellation_qam64_snr20dB.fig');
saveas(gcf, 'received_constellation_qam64_snr20dB.png');
fprintf('Number of errors (QAM, M=64, SNR=20 dB): %i\n', sum(i_data ~= qamdemod(rx_sig_qam64_20dB, M)));


scatterplot(rx_sig_psk8_20dB);
title('Received Constellation (PSK, M=8, SNR=20 dB)');
saveas(gcf, 'received_constellation_psk8_snr20dB.fig');
saveas(gcf, 'received_constellation_psk8_snr20dB.png');
fprintf('Number of errors (PSK, M=8, SNR=20 dB): %i\n', sum(i_data ~= pskdemod(rx_sig_psk8_20dB, M)));

% 9. Repeat 8 for SNR=12 dB
rx_sig_qam64_12dB = awgn(tx_sig_qam64, 12);
rx_sig_psk8_12dB = awgn(tx_sig_psk8, 12);

% Show received constellation using scatterplot and report the number of errors

scatterplot(rx_sig_qam64_12dB);
title('Received Constellation (QAM, M=64, SNR=12 dB)');
saveas(gcf, 'received_constellation_qam64_snr12dB.fig');
saveas(gcf, 'received_constellation_qam64_snr12dB.png');
fprintf('Number of errors (QAM, M=64, SNR=12 dB): %i\n', sum(i_data ~= qamdemod(rx_sig_qam64_12dB, M)));


scatterplot(rx_sig_psk8_12dB);
title('Received Constellation (PSK, M=8, SNR=12 dB)');
saveas(gcf, 'received_constellation_psk8_snr12dB.fig');
saveas(gcf, 'received_constellation_psk8_snr12dB.png');
fprintf('Number of errors (PSK, M=8, SNR=12 dB): %i\n', sum(i_data ~= pskdemod(rx_sig_psk8_12dB, M)));

% 10. Create an 8-PSK waveform and add AWGN as an impairment at 12 dB SNR
tx_sig_psk8_waveform = pskmod(i_data, M);
rx_sig_psk8_waveform = awgn(tx_sig_psk8_waveform, 12);

% Show received constellation using scatterplot

scatterplot(rx_sig_psk8_waveform);
title('Received Constellation (8-PSK Waveform, SNR=12 dB)');
saveas(gcf, 'received_constellation_psk8_waveform_snr12dB.fig');
saveas(gcf, 'received_constellation_psk8_waveform_snr12dB.png');
