SIR_values = [5, 8, 10, 20];  % SIR values in dB
Ldata = 20000;                % data length in simulation
Lc = 11;                      % spreading factor vs data rate

BER = [];                     % Initialize BER storage
BER_az = [];                  % Initialize analytical BER storage
figber = figure;              % Create a figure for BER plots

% Make sure other necessary variables are also initialized
data_sym = 2*round(rand(Ldata, 1)) - 1 + j*(2*round(rand(Ldata, 1)) - 1); % Example QPSK data symbols initialization
pcode = [1 1 1 -1 -1 -1 1 -1 -1 1 -1]';                                   % Example spreading code
x_in = kron(data_sym, pcode);                                             % Spread signal
noiseq = randn(Ldata*Lc, 1) + j*randn(Ldata*Lc, 1);                       % Noise vector initialization

for SIR = SIR_values
    Pj = 2 * Lc / (10^(SIR/10)); % Calculate jamming power for current SIR
    jammer = sqrt(Pj/2) * exp(j*2*pi*0.12*(1:Ldata*Lc)).';                % Generate jamming signal
    
    % Simulate system for current SIR
    for i = 1:10
        Eb2N(i) = (i-1); % (Eb/N in dB)
        Eb2N_num = 10^(Eb2N(i)/10); % Convert Eb/N from dB to numeral
        Var_n = Lc / (2*Eb2N_num);  % Noise variance
        signois = sqrt(Var_n);      % Standard deviation of noise
        awgnois = signois * noiseq; % Generate AWGN

        % Add noise and jamming to signal
        y_out = x_in + awgnois + jammer;
        Y_out = reshape(y_out, Lc, Ldata).';
        clear y_out awgnois;

        % Despread
        z_out = Y_out * pcode;

        % Make decisions
        dec1 = sign(real(z_out)) + j*sign(imag(z_out));

        % Calculate BER
        BER(i, find(SIR == SIR_values)) = sum([real(data_sym) ~= real(dec1); imag(data_sym) ~= imag(dec1)]) / (2*Ldata);
        BER_az(i, find(SIR == SIR_values)) = 0.5 * erfc(sqrt(Eb2N_num)); % Analytical BER
    end
end

% Plot results for each SIR value
colors = ['k', 'r', 'b', 'g']; % Colors for different SIR curves
hold on;
for idx = 1:length(SIR_values)
    semilogy(Eb2N, BER_az(:, idx), [colors(idx) '-'], Eb2N, BER(:, idx), [colors(idx) 'o-'], 'LineWidth', 2);
end
hold off;
legend(arrayfun(@(x) sprintf('SIR = %d dB', x), SIR_values, 'UniformOutput', false));
xlabel('E_b/N (dB)');
ylabel('Bit error rate');
title('DSSS (CDMA) Performance under Different SIRs');
