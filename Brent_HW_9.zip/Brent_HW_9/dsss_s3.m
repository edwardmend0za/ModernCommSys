clear; clf;
Ldata = 20000;  % data length in simulation; Must be divisible by 8
Lc = 11;        % spreading factor vs data rate.

% Generate QPSK modulation symbols
data_sym = 2*round(rand(Ldata, 1)) - 1 + j*(2*round(rand(Ldata, 1)) - 1);
ns_data_sym = 2*round(rand(Ldata, 1)) - 1 + j*(2*round(rand(Ldata, 1)) - 1); % Non-spread QPSK

% Generating a spreading code
pcode = [1 1 1 -1 -1 -1 1 -1 -1 1 -1]';

% Now spread
x_in = kron(data_sym, pcode);

% Calculate PSD of spread signal
[P, x] = pwelch(x_in, [], [], [4096], Lc, 'twosided');
figure(1);
semilogy(x - Lc/2, fftshift(P));
title('CDMA Signal PSD');
xlabel('frequency (in unit of 1/T_s)');
ylabel('Power Spectral Density');
axis([-Lc/2 Lc/2 1.e-2 1.e2]);
grid;

% Calculate and plot PSD of the non-spread QPSK signal
[P_ns, x_ns] = pwelch(ns_data_sym, [], [], [4096], 'twosided');
figure(2);
semilogy(x_ns - 1/2, fftshift(P_ns));
title('PSD of Non-Spread QPSK Signal');
xlabel('frequency (in unit of 1/T_s)');
ylabel('Power Spectral Density');
axis([-1/2 1/2 1.e-2 1.e2]);
grid;
