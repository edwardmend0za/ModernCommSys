clear; clf;
Ldata = 20000;  % data length in simulation; Must be divisible by 8
Lc = 11;        % spreading factor vs data rate.
SIR_values = [5, 8, 10, 20];  % SIR values in dB

% Generate QPSK modulation symbols
data_sym = 2*round(rand(Ldata, 1)) - 1 + j*(2*round(rand(Ldata, 1)) - 1);
ns_data_sym = data_sym; % Non-spread QPSK is the same data

% Generating a spreading code
pcode = [1 1 1 -1 -1 -1 1 -1 -1 1 -1]';

% Now spread
x_in = kron(data_sym, pcode);

% Generate noise (AWGN)
noiseq = randn(Ldata*Lc, 1) + j*randn(Ldata*Lc, 1); % Power is 2

BER = [];    % Initialize BER storage for spread signal
BER_ns = []; % Initialize BER storage for non-spread signal

% Simulation loop for each SIR
for SIR = SIR_values
    Pj = 2 * (10^(SIR/10)); % Jamming power relative to non-spread signal power

    % Generate jamming signal
    jam_data = 2*round(rand(Ldata, 1)) - 1 + j*(2*round(rand(Ldata, 1)) - 1); % QPSK jamming
    jam_mod = kron(jam_data, ones(Lc, 1));
    jammer = sqrt(Pj/2) * jam_mod .* exp(j*2*pi*0.12*(1:Ldata*Lc)).';

    % Simulate system for current SIR
    for i = 1:10
        Eb2N(i) = (i-1); % (Eb/N in dB)
        Eb2N_num = 10^(Eb2N(i)/10); % Convert Eb/N from dB to numeral
        Var_n = 1 / (2*Eb2N_num);  % Noise variance for non-spread
        signois = sqrt(Var_n);     % Standard deviation of noise
        awgnois = signois * noiseq; % Generate AWGN

        % Add noise and jamming to spread and non-spread signal
        y_out = x_in + awgnois + jammer;
        y_ns_out = ns_data_sym + awgnois(1:Ldata) + jammer(1:Ldata)/sqrt(Lc); % Scale jammer for non-spread

        % Despread and decision for spread signal
        Y_out = reshape(y_out, Lc, Ldata).';
        z_out = Y_out * pcode;
        dec1 = sign(real(z_out)) + j*sign(imag(z_out));

        % Decision for non-spread signal
        dec1_ns = sign(real(y_ns_out)) + j*sign(imag(y_ns_out));

        % Calculate BER
        BER(i, find(SIR == SIR_values)) = sum([real(data_sym) ~= real(dec1); imag(data_sym) ~= imag(dec1)]) / (2*Ldata);
        BER_ns(i, find(SIR == SIR_values)) = sum([real(ns_data_sym) ~= real(dec1_ns); imag(ns_data_sym) ~= imag(dec1_ns)]) / (2*Ldata);
    end
end

% Plot results for spread signal
figure;
colors = ['k', 'r', 'b', 'g']; % Colors for different SIR curves
hold on;
for idx = 1:length(SIR_values)
    semilogy(Eb2N, BER(:, idx), [colors(idx) 'o-'], 'LineWidth', 2);
end
hold off;
legend(arrayfun(@(x) sprintf('SIR = %d dB Spread', x), SIR_values, 'UniformOutput', false));
xlabel('E_b/N (dB)');
ylabel('Bit error rate');
title('DSSS (CDMA) Performance under Different SIRs');

% Plot results for non-spread signal
figure;
hold on;
for idx = 1:length(SIR_values)
    semilogy(Eb2N, BER_ns(:, idx), [colors(idx) 'x-'], 'LineWidth', 2);
end
hold off;
legend(arrayfun(@(x) sprintf('SIR = %d dB Non-Spread', x), SIR_values, 'UniformOutput', false));
xlabel('E_b/N (dB)');
ylabel('Bit error rate');
title('Non-Spread QPSK Performance under Different SIRs');
