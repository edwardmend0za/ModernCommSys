% Draw 1000 samples from a uniform distribution with limits -pi to +pi
uniform_samples = -pi + (2*pi) * rand(1000, 1);

% Plot histogram
figure;
histogram(uniform_samples, 30); 
title('Uniform Distribution Histogram');
xlabel('Value');
ylabel('Frequency');
grid on;

% Save histogram as JPEG
saveas(gcf, 'uniform_distribution_histogram.jpg');

% Draw 1000 samples from a Gaussian distribution with mean = 0 and variance = 1
gaussian_samples_1 = randn(1000, 1);

% Plot histogram
figure;
histogram(gaussian_samples_1, 30); % Adjust the number of bins as needed
title('Gaussian Distribution (Mean=0, Variance=1) Histogram');
xlabel('Value');
ylabel('Frequency');
grid on;

% Save histogram as JPEG
saveas(gcf, 'gaussian_distribution_mean_0_variance_1_histogram.jpg');

% Draw 1000 samples from a Gaussian distribution with mean = 10 and variance = 5
gaussian_samples_2 = sqrt(5) * randn(1000, 1) + 10;

% Plot histogram
figure;
histogram(gaussian_samples_2, 30); 
title('Gaussian Distribution (Mean=10, Variance=5) Histogram');
xlabel('Value');
ylabel('Frequency');
grid on;

% Save histogram as JPEG
saveas(gcf, 'gaussian_distribution_mean_10_variance_5_histogram.jpg');
